# vf_inverter
Simple scalar (V/f) inverter of induction motor, using the 8051 in PWM technique
